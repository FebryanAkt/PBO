public class Kucing extends Hewan{

    @Override
    public void bergerak(){
        // throw new UnsupportedOperationException("Not supported yet.");
        System.out.println("Berjalan dengan KAKI, \"tap..tap..\"");
    }
    
}
