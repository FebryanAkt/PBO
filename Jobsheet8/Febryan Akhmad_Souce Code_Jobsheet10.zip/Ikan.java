public class Ikan extends Hewan {
    
    @Override
    public void bergerak(){
        // throw new UnsupportedOperationException("Not supported yet.");
        System.out.println("Berenang dengan SIRIP, \"wush..wush..\"");
    }
}
