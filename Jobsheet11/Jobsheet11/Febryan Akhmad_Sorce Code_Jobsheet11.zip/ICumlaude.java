public interface ICumlaude {
    public abstract void Lulus();
    public abstract void meraihIPKTinggi();
}
