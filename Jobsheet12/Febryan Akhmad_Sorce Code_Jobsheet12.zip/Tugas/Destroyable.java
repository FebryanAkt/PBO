package Tugas;

public interface Destroyable {
    public void destroyed();
}

