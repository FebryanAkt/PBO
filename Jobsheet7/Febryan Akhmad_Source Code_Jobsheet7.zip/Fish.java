public class Fish {
    public static void main(String[] args) {
        Ikan a = new Ikan();
        Ikan b = new Ikan();
        a.swim();
        b.swim();
   }
}
