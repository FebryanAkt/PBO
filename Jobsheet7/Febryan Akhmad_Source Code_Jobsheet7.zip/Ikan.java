public class Ikan {
    public void swim(){
        System.out.println("Ikan bisa berenang");
    }
}
