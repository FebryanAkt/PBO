public class Mahasiswa extends Manusia {
    public void makan(){

    }
    public void tidur(){
        
    }
}
 