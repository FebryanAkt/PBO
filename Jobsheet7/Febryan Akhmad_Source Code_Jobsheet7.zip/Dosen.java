public class Dosen extends Manusia {
    public void makan(){

    }
    public void lembur(){
        
    }
}
