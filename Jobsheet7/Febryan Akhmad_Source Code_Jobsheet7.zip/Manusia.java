public class Manusia {
    public void bernafas(){

    }
    public void makan(){
        
    }
}
