public class ClassCPercobaan4 extends ClassBPercobaan4 {
    ClassCPercobaan4(){
        super();
        System.out.println("konstruktor C dijalankan");
    }
}
