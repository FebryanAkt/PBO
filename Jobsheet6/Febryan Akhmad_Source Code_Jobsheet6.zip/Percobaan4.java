public class Percobaan4 {
    public static void main(String[] args) {
        ClassCPercobaan4 test = new ClassCPercobaan4();
    }
}
