public class ClassBPercobaan4 extends ClassAPercobaan4{
    ClassBPercobaan4(){
        System.out.println("konstruktor B dijalankan");
    }
}
