public class Pecobaan2 extends ClassBPercobaan2{
    public static void main(String[] args) {
        ClassBPercobaan2 hitung = new ClassBPercobaan2();
        hitung.setx(20);
        hitung.setY(30);
        hitung.setZ(5);
        hitung.getNilai();
        hitung.getNilaiZ();
        hitung.getJumlah();
    }
}
