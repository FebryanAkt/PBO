public class ClassAPercobaan2 {
    protected int x;
    protected int y;

    public void setx(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    public void getNilai(){
        System.out.println("Nilai X:" + x);
        System.out.println("Nilai Y:" + y);
    }
}
