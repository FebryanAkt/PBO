public class ClassAPercobaan4 {
    ClassAPercobaan4(){
        System.out.println("konstruktor A dijalankan");
    }
}
